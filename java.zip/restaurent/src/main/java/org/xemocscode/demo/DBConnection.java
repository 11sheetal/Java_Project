/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.xemocscode.demo;
import java.sql.*;
/**
 *
 * @author Admin
 */
public class DBConnection {
   
    static final String DB_URL="jdbc:mysql://localhost/demo";
    static final String Username="root";
    static final String Password="12001180";
    public static Connection connectDB()
    {
         Connection conn=null;
        try
        {
          Class.forName("com.mysql.jdbc.Driver");
          conn=DriverManager.getConnection(DB_URL,Username,Password);
          return conn;
        }
        catch(Exception ex)
        {
            System.out.println("there were errors while connecting to db.");
            return null;
        }
    }
}
